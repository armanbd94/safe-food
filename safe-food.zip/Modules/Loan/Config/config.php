<?php

return [
    'name' => 'Loan'
];
