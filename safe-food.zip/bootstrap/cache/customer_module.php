<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Customer\\Providers\\CustomerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Customer\\Providers\\CustomerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);