<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Loan\\Providers\\LoanServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Loan\\Providers\\LoanServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);