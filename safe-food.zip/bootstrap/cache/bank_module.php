<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Bank\\Providers\\BankServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Bank\\Providers\\BankServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);