<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SalesMen\\Providers\\SalesMenServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SalesMen\\Providers\\SalesMenServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);