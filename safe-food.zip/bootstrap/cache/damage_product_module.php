<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DamageProduct\\Providers\\DamageProductServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DamageProduct\\Providers\\DamageProductServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);