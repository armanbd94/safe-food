<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\MaterialStockOut\\Providers\\MaterialStockOutServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\MaterialStockOut\\Providers\\MaterialStockOutServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);