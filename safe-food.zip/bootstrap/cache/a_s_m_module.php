<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ASM\\Providers\\ASMServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ASM\\Providers\\ASMServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);